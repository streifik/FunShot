//
//  ChatEmail+CoreDataClass.swift
//  teatApp
//
//  Created by streifik on 22.12.2022.
//
//

import Foundation
import CoreData

@objc(ChatEmail)
public class ChatEmail: NSManagedObject {

}
