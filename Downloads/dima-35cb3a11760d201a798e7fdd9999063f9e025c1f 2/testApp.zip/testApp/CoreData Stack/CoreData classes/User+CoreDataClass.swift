//
//  User+CoreDataClass.swift
//  teatApp
//
//  Created by streifik on 09.12.2022.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
